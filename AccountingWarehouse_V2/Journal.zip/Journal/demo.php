 <!--?php
include("../include/connection.php");
$output = array();

$JMID=isset($_POST['JMID']) ? $_POST['JMID'] : '0';

//---- Journal Master Record 
 $sql="SELECT *
                 FROM journalmaster where ID=".$JMID;
                

  

$statement = $conn->prepare($sql);
$statement->execute();
$result = $statement->fetchAll();

$output=[];

foreach($result as $row)
{
 //$file_array = explode(".", $row["name"]);
 $output['JournalDate'] = $row["JournalDate"];//$row["name"]
 $output['AccType'] = $row["AccType"];
$output['Invoice'] = $row["Invocie"];


 //Invoice
}
//---- Journal Detail Record 
/*
$sql="SELECT *
                 FROM  journal where JMID=".$JMID;
                



$statement = $conn->prepare($sql);
$statement->execute();
$result = $statement->fetchAll();



foreach($result as $row)
{
 //$file_array = explode(".", $row["name"]);
 $output['account'] = array("accouts"=>$row["accounts"],
    "description"=>$row["description"],
    "debit"=>$row["debit"],
    "credit"=>$row["credit"]


 );//$row["name"]

 //Invoice
}


 


echo json_encode($output); */

//echo $output;








 

    //"Records inserted successfully.";

/*
$sql='delete from  tbl_menuassign  where RoleID='.$Role;
if(mysqli_query($link, $sql)){
    $output['Save'] ="Records inserted successfully.";
} else{
   $output['Save'] ="ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

$data = json_decode(stripslashes($_POST['menu']));

  // here i would like use foreach:

  foreach($data as $d){
   //  echo $Menu;
  
  $sql='INSERT INTO `tbl_menuassign`( `MenuID`, `IsActive`, `RoleID`) VALUES (
  '.$d.',
  1,
  '.$Role.')';
  if(mysqli_query($link, $sql)){
   $output['Save'] ="Records inserted successfully.";
} else{
   $output['Save'] ="ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
*/

 
echo json_encode($output);
//mysqli_close($conn);
?-->